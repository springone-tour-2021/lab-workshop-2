Any files in this directory that have a suffix of `.sh` will be executed
when the container is started. See the following for more information:

https://docs.edukates.io/en/latest/workshop-content/workshop-runtime.html#running-steps-on-container-start