Any files or directories that appear in this location will show up
in the home directory of student when the workshop is launched and
also available via the docs web server image.